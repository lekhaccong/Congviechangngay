# Công Việc Hằng Ngày v2 — GitHub Build

Upload toàn bộ nội dung project này vào repository GitHub, giữ nguyên thư mục `.github/workflows/build-apk.yml`.

Sau khi Commit:
1. Mở Actions.
2. Chọn Build Android APK.
3. Run workflow.
4. Khi hoàn tất, mở workflow run.
5. Tải Artifact `CongViecHangNgay-v2-debug`.
6. Giải nén và cài `app-debug.apk`.

Bản v2 có 4 ca, 18 việc, 30 phút/việc, Todo tồn đọng, hạn, tiến độ, cảnh báo quá hạn và chia sẻ vấn đề.
Camera/lưu ảnh và cơ sở dữ liệu vĩnh viễn sẽ được ghép ở bản nâng cấp kế tiếp sau khi xác nhận APK nền build thành công.
